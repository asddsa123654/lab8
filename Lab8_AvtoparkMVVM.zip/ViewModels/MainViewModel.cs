using Microsoft.EntityFrameworkCore;
using System.Collections.ObjectModel;
using System.Linq;

public class MainViewModel : BindableBase
{
    private readonly AppDbContext _dbContext;

    public MainViewModel()
    {
        _dbContext = new AppDbContext();
        _dbContext.Database.EnsureCreated();
        _dbContext.Cars.Load();
        ReloadCars();
    }

    private void ReloadCars()
    {
        var items = _dbContext.Cars.Local.OrderBy(c => c.Brand).ToList();
        Cars.Clear();
        items.ForEach(c => Cars.Add(c));
    }

    public ObservableCollection<Car> Cars { get; set; } = new ObservableCollection<Car>();

    private string _brand, _model, _status;
    private int _year;

    public string NewCarBrand { get => _brand; set => SetProperty(ref _brand, value); }
    public string NewCarModel { get => _model; set => SetProperty(ref _model, value); }
    public int NewCarYear { get => _year; set => SetProperty(ref _year, value); }
    public string NewCarStatus { get => _status; set => SetProperty(ref _status, value); }

    public void SaveNewCar()
    {
        _dbContext.Add(new Car
        {
            Brand = NewCarBrand,
            Model = NewCarModel,
            Year = NewCarYear,
            Status = NewCarStatus
        });
        _dbContext.SaveChanges();
        ReloadCars();
        ClearNewCar();
    }

    public void ClearNewCar()
    {
        NewCarBrand = "";
        NewCarModel = "";
        NewCarStatus = "";
        NewCarYear = 0;
    }

    public int TotalCount => Cars.Count;
}