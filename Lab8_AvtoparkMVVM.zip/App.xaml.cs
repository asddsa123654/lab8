sealed partial class App : Application
{
    public static MainViewModel ViewModel { get; } = new MainViewModel();

    public App()
    {
        this.InitializeComponent();
    }
}